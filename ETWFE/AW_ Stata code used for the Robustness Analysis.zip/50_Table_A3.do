******************************************************************************************************************************
******************************************************************************************************************************
***
*** Table A3: Robustness with regard to degree of heterogeneity of the ETWFE estimator and incidental parameter problems
*** 
******************************************************************************************************************************
******************************************************************************************************************************

** open data set
use ${usr_data}\data_sdid_small, clear

** 0) Baseline
local spec "Baseline"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time)
estimates save "${usr_data}\base_`spec'.ster", replace
global N_coef_`spec' = colsof(e(b))-1
gen sample_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
count if sample_`spec'==1
global N_all_`spec' = `r(N)'
unique exporter if sample_`spec'==1
global N_E_`spec' = `r(unique)'
unique importer if sample_`spec'==1
global N_I_`spec' = `r(unique)'
unique year if sample_`spec'==1
global N_T_`spec' = `r(unique)'


** 1) Event study
local spec "RESE"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time) restriction(event)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator "ETWFE"
estadd local Unit_heterogeneity ""
estadd local Time_heterogeneity "Year"
estadd local Binning ""
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
estadd local Year ""
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 2) Only cohort heterogeneity
local spec "RESG"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time) restriction(group)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator "ETWFE"
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity ""
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
estadd local Year ""
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 3) Cohort-agreement heterogeneity X 5-year intervals
local spec "REST_AGRHET"
jwdid trade  if first_treat_LARCH_3==first_treat_3, ivar(id_ci_cj) tvar(year) gvar(first_treat_LARCH_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time) restriction(exporter) interval(5) addint(RTAINDALT1)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator "ETWFE"
estadd local Sample_name "Same RTA"
estadd local Unit_heterogeneity "Coh\$\times \$ RTAID"
estadd local Time_heterogeneity "5yr"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
estadd local Year ""
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 4) Baseline specification, but sample restricted to (3)
local spec "REST"
jwdid trade if sample_JWDID_REST_AGRHET==1, ivar(id_ci_cj) tvar(year) gvar(first_treat_LARCH_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator "ETWFE"
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
estadd local Year ""
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'
preserve
keep idt_ci idt_cj sample_JWDID_`spec'
keep if sample_JWDID_`spec'==1
save ${usr_data}\sample_JWDID_`spec', replace
restore


** 5) ETWFE - Only pair and year FE
local spec "SAMEFE"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe)
local col_B = colsof(e(b))-1
mat temp = r(table)
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator "ETWFE"
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Exporter_Year ""
estadd local Importer_Year ""
estadd local Year "Yes"
estadd local Intra_Year ""
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'

* extract year and first_treat_3
scalar dim_B = `=colsof(temp)'-1
mat B=temp[1,1..`=dim_B']
mat index=J(1,`=dim_B',.)
mat year=J(1,`=dim_B',.)
mat first_treat_3=J(1,`=dim_B',.)
local names: colnames B
forval i=1(1)`=dim_B' {
	mat index[1,`i'] = `i'
	local name : word `i' of `names'
	local temp = substr("`name'",1,4)
	mat first_treat_3[1,`i'] = `temp'
	local hash_idx = strpos("`name'","#")
	local temp = substr("`name'",`hash_idx'+1,4)
	mat year[1,`i'] =  `temp'
}


** 6) Imputation estimator - Only pair and year FE
ppmlhdfe trade if (year<first_treat_3 | first_treat_3==0) & sample_JWDID_SAMEFE, abs(id_ci_cj year, savefe) d
mat temp=e(b)

* loop over FEs
local ctr = 1
foreach FE in id_ci_cj year {
	gen __hdfe`ctr'__imp = __hdfe`ctr'__
	egen temp = min(__hdfe`ctr'__), by(`FE')
	replace __hdfe`ctr'__imp = temp if __hdfe`ctr'__imp==. & sample_JWDID_SAMEFE
	drop temp	
	local ctr = `ctr'+1
}

gen double trade_imp = exp(__hdfe1__imp+__hdfe2__imp+temp[1,1]) if sample_JWDID_SAMEFE
gen te_trade = trade - trade_imp if sample_JWDID_SAMEFE
gen sample2=1 if te_trade!=.

mat B_imp=J(1,`=dim_B',.)

local B_agg = 0
local total = 0
forval j=1(1)`=dim_B' {	
	qui sum trade if first_treat_3==first_treat_3[1,`j'] & year==year[1,`j'] & sample_JWDID_SAMEFE
	if `r(N)'!=0 {
		local temp_trade = `r(mean)'
	}
	qui sum trade_imp if first_treat_3==first_treat_3[1,`j'] & year==year[1,`j'] & sample_JWDID_SAMEFE
	if `r(N)'!=0 {
		local temp_trade_imp = `r(mean)'
		local total = `total'+`r(N)'
		mat B_imp[1,`j'] = ln(`temp_trade')-ln(`temp_trade_imp')
		local B_agg = `B_agg' + B_imp[1,`j']*`r(N)'
	}
}
local B_agg = `B_agg'/`total'
gen sample_IMP_`spec' = sample2
gen __tr__IMP_`spec' = __tr__
gen __etr__IMP_`spec' = __etr__
gen _ppmlhdfe_d_IMP_`spec' = _ppmlhdfe_d
mat B = `B_agg'
mat V = 0
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo IMP_`spec'
* store remaining results
estadd local Estimator "Imputation"
estadd local Unit_heterogeneity "Pair"
estadd local Time_heterogeneity "Year"
estadd local Exporter_Year ""
estadd local Importer_Year ""
estadd local Year "Yes"
estadd local Intra_Year ""
estadd local Exporter_Importer "Yes"
count if sample_IMP_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_IMP_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_IMP_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_IMP_`spec'==1
estadd scalar N_T = `r(unique)'


** 7) Imputation estimator - Same FEs as in baseline
local spec "MAIN"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time)
gen sample_JWDID_`spec' = e(sample)
ppmlhdfe trade if (year<first_treat_3 | first_treat_3==0) & sample_JWDID_MAIN, abs(id_ci_cj idt_ci idt_cj brdr_time, savefe) d
mat temp=e(b)

* loop over FEs
local ctr = 1
foreach FE in id_ci_cj idt_ci idt_cj brdr_time {
	gen __hdfe`ctr'__imp = __hdfe`ctr'__
	egen temp = min(__hdfe`ctr'__), by(`FE')
	replace __hdfe`ctr'__imp = temp if __hdfe`ctr'__imp==. & sample_JWDID_MAIN
	drop temp	
	local ctr = `ctr'+1
}

gen double trade_imp_MAIN = exp(__hdfe1__imp+__hdfe2__imp+__hdfe3__imp+__hdfe4__imp+temp[1,1]) if sample_JWDID_MAIN
gen te_trade_MAIN = trade - trade_imp_MAIN if sample_JWDID_MAIN
gen sample2_MAIN=1 if te_trade_MAIN!=.

mat B_imp=J(1,`=dim_B',.)

local B_agg = 0
local total = 0
forval j=1(1)`=dim_B' {	
	qui sum trade if first_treat_3==first_treat_3[1,`j'] & year==year[1,`j'] & sample_JWDID_MAIN
	if `r(N)'!=0 {
		local temp_trade = `r(mean)'
	}
	qui sum trade_imp_MAIN if first_treat_3==first_treat_3[1,`j'] & year==year[1,`j'] & sample_JWDID_MAIN
	if `r(N)'!=0 {
		local temp_trade_imp = `r(mean)'
		local total = `total'+`r(N)'
		mat B_imp[1,`j'] = ln(`temp_trade')-ln(`temp_trade_imp')
		local B_agg = `B_agg' + B_imp[1,`j']*`r(N)'
	}
}
local B_agg = `B_agg'/`total'
gen sample_IMP_`spec' = sample2
gen __tr__IMP_`spec' = __tr__
gen __etr__IMP_`spec' = __etr__
gen _ppmlhdfe_d_IMP_`spec' = _ppmlhdfe_d
mat B = `B_agg'
mat V = 0
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo IMP_`spec'
* store remaining results
estadd local Estimator "Imputation"
estadd local Unit_heterogeneity "Pair"
estadd local Time_heterogeneity "Year"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Year ""
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_IMP_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_IMP_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_IMP_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_IMP_`spec'==1
estadd scalar N_T = `r(unique)'


// save post estimation data set
save ${usr_data}\data_sdid_robustness_heterogeneity_post, replace


/////////////////////////
/// Write LaTeX table ///
/////////////////////////

esttab JWDID_RESE JWDID_RESG JWDID_REST_AGRHET JWDID_REST JWDID_SAMEFE IMP_SAMEFE IMP_MAIN using "${path_tables}/Table_A3.tex", se label ///
			star(* 0.10 ** 0.05 *** 0.01) ///
			replace substitute(\_ _) nonotes noobs nomtitles b(%9.3f) se(%9.3f) ///
			scalars("Estimator Estimator" "Unit_heterogeneity \hline Unit heterogeneity" "Time_heterogeneity Time heterogeneity" "N_all \hline  Observations" "N_E Exporters" "N_I Importers" "N_T Years" "N_coef Coefficients" ///
			 "Exporter_Importer \hline Exporter \$\times\$ importer FE" "Exporter_Year Exporter \$\times\$ year FE" "Importer_Year Importer \$\times\$ year FE" "Intra_Year Cross-border \$\times\$ year FE" "Year Year FE") ///
			sfmt(%12.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc) ///
		coef(RTA_3 "\$ RTA_{ij,t}\$")
