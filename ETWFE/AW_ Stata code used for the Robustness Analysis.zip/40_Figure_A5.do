******************************************************************************************************************************
******************************************************************************************************************************
***
*** Figure A5: Mean number of provisions by cohort
*** 
******************************************************************************************************************************
******************************************************************************************************************************

// load data set
use ${usr_data}\data_sdid_small.dta, clear

* compute maximum number of provisions by pair over time
egen max_DEPTH = max(DEPTH), by(id_ci_cj)

keep if first_treat_3==year
collapse (mean) max_DEPTH, by(year)
replace year=year+3
scatter max_DEPTH year, xtitle("Treatment cohorts",size(large)) ytitle("Mean number of provisions",size(large)) xlabel(,labsize(large) nogrid) ylabel(,labsize(large) nogrid) color(black)
graph export "${path_figures}/Figure_A5.eps", replace as(eps) fontface("Arial Narrow")
