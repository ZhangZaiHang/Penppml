******************************************************************************************************************************
******************************************************************************************************************************
***
*** Table A5: Robustness with regard to different DiD-specific assumptions
***
*** Requirement: Run "20_Figure_3.do" first
***
******************************************************************************************************************************
******************************************************************************************************************************

** open data set
use ${usr_data}\data_sdid_small, clear

* additional definitions
gen notyet = (first_treat_3>0 & first_treat_3!=.)


** 0) Baseline
local spec "MAIN"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Binning ""
estadd local Not_yet "Yes"
estadd local Never "Yes"
estadd local Omit_anticipation ""
estadd local lnDIST ""
estadd local CNTG ""
estadd local CLNY ""
estadd local LANG ""
estadd local Weights "Obs"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 1) Restriction for t>10
local spec "BINT10"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time) binT(10)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Binning "10yr+"
estadd local Not_yet "Yes"
estadd local Never "Yes"
estadd local Omit_anticipation ""
estadd local lnDIST ""
estadd local CNTG ""
estadd local CLNY ""
estadd local LANG ""
estadd local Weights "Obs"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
estadd local Year ""
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 2) 2-year intervals
local spec "2YRINT"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time) interval(2)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "2yr"
estadd local Binning ""
estadd local Not_yet "Yes"
estadd local Never "Yes"
estadd local Omit_anticipation ""
estadd local lnDIST ""
estadd local CNTG ""
estadd local CLNY ""
estadd local LANG ""
estadd local Weights "Obs"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
estadd local Year ""
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 3) 5-year intervals
local spec "5YRINT"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time) interval(5)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "5yr"
estadd local Binning ""
estadd local Not_yet "Yes"
estadd local Never "Yes"
estadd local Omit_anticipation ""
estadd local lnDIST ""
estadd local CNTG ""
estadd local CLNY ""
estadd local LANG ""
estadd local Weights "Obs"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
estadd local Year ""
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 4) Control group: Never treated (saturation with FEs)
local spec "NEVER1"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time) never
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Binning ""
estadd local Not_yet ""
estadd local Never "Yes"
estadd local Omit_anticipation ""
estadd local lnDIST ""
estadd local CNTG ""
estadd local CLNY ""
estadd local LANG ""
estadd local Weights "Obs"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 5) Control group: Never treated (drop obs)
local spec "NEVER2"
gen NEVER2 = 1
replace NEVER2 = 0 if year+1<first_treat_3 & first_treat_3!=0
jwdid trade if NEVER2==1, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time) never
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Binning ""
estadd local Not_yet ""
estadd local Never "Yes"
estadd local Omit_anticipation ""
estadd local lnDIST ""
estadd local CNTG ""
estadd local CLNY ""
estadd local LANG ""
estadd local Weights "Obs"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 6) Control group: not-yet treated
local spec "NOTYET"
jwdid trade if notyet==1, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Binning ""
estadd local Not_yet "Yes"
estadd local Never ""
estadd local Omit_anticipation ""
estadd local lnDIST ""
estadd local CNTG ""
estadd local CLNY ""
estadd local LANG ""
estadd local Weights "Obs"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 7) Drop no anticipation period observations
local spec "DRPANT"
jwdid trade if exclude!=1, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Binning ""
estadd local Not_yet "Yes"
estadd local Never "Yes"
estadd local Omit_anticipation "Yes"
estadd local lnDIST ""
estadd local CNTG ""
estadd local CLNY ""
estadd local LANG ""
estadd local Weights "Obs"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 8) Condition on the log of distance
local spec "COVDIST"
jwdid trade DIST, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Binning ""
estadd local Not_yet "Yes"
estadd local Never "Yes"
estadd local Omit_anticipation ""
estadd local lnDIST "Yes"
estadd local CNTG ""
estadd local CLNY ""
estadd local LANG ""
estadd local Weights "Obs"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 9) Condition on all gravity variables
local spec "COVGRAV"
jwdid trade DIST CNTG CLNY LANG, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Binning ""
estadd local Not_yet "Yes"
estadd local Never "Yes"
estadd local Omit_anticipation ""
estadd local lnDIST "Yes"
estadd local CNTG "Yes"
estadd local CLNY "Yes"
estadd local LANG "Yes"
estadd local Weights "Obs"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'

** alternative weighting schemes

* open post-estimation data
use ${usr_data}\data_sdid_figures_post, clear

// define weights

* weight uniformly (as is baseline) by number of observations
gen w_unif = __etr__

* weight by cohort
egen temp = sum(w_unif), by(first_treat_3)
gen w_g = w_unif/temp
replace w_g = 0 if w_g==.
drop temp

* weight by event year
capture drop event
gen event = year - first_treat_3
egen temp = sum(w_unif), by(event)
gen w_t = w_unif/temp
replace w_t = 0 if w_t==.
drop temp event

* weight by cohort-year
egen temp = sum(w_unif), by(first_treat_3 year)
gen w_gt = w_unif/temp
replace w_gt = 0 if w_gt==.
drop temp

* weight by pair
egen temp = sum(w_unif), by(id_ci_cj)
gen w_ij = w_unif/temp
replace w_ij = 0 if w_ij==.
drop temp


* weight uniformly (as is baseline) by number of observations [confirms that results are the same]
local suffix = "_MAIN"
local event_gvar = "first_treat_3"
estimates use "${usr_data}\base`suffix'.ster"
estimates esample: if sample_JWDID`suffix'
local col_B = colsof(e(b))-1
local spec = "MAIN_2"
margins [aweight=w_unif],  subpop(if __etr__==1) at(__tr__=(0 1)) noestimcheck contrast(atcontrast(r)) predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Binning ""
estadd local Not_yet "Yes"
estadd local Never "Yes"
estadd local Omit_anticipation ""
estadd local lnDIST ""
estadd local CNTG ""
estadd local CLNY ""
estadd local LANG ""
estadd local Weights "Obs"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID`suffix'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID`suffix'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID`suffix'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID`suffix'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


* 10) weight by cohort
local suffix = "_MAIN"
local event_gvar = "first_treat_3"
estimates use "${usr_data}\base`suffix'.ster"
estimates esample: if sample_JWDID`suffix'
local col_B = colsof(e(b))-1
local spec = "g"
margins [aweight=w_g],  subpop(if __etr__==1) at(__tr__=(0 1)) noestimcheck contrast(atcontrast(r)) predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Binning ""
estadd local Not_yet "Yes"
estadd local Never "Yes"
estadd local Omit_anticipation ""
estadd local lnDIST ""
estadd local CNTG ""
estadd local CLNY ""
estadd local LANG ""
estadd local Weights "Cohort"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID`suffix'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID`suffix'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID`suffix'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID`suffix'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


* 11) weight by event year
local suffix = "_MAIN"
local event_gvar = "first_treat_3"
estimates use "${usr_data}\base`suffix'.ster"
estimates esample: if sample_JWDID`suffix'
local col_B = colsof(e(b))-1
local spec = "t"
margins [aweight=w_t],  subpop(if __etr__==1) at(__tr__=(0 1)) noestimcheck contrast(atcontrast(r)) predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Binning ""
estadd local Not_yet "Yes"
estadd local Never "Yes"
estadd local Omit_anticipation ""
estadd local lnDIST ""
estadd local CNTG ""
estadd local CLNY ""
estadd local LANG ""
estadd local Weights "Year"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID`suffix'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID`suffix'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID`suffix'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID`suffix'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


* 12) weight by cohort-year
local suffix = "_MAIN"
local event_gvar = "first_treat_3"
estimates use "${usr_data}\base`suffix'.ster"
estimates esample: if sample_JWDID`suffix'
local col_B = colsof(e(b))-1
local spec = "gt"
margins [aweight=w_gt],  subpop(if __etr__==1) at(__tr__=(0 1)) noestimcheck contrast(atcontrast(r)) predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Unit_heterogeneity "Cohort"
estadd local Time_heterogeneity "Year"
estadd local Binning ""
estadd local Not_yet "Yes"
estadd local Never "Yes"
estadd local Omit_anticipation ""
estadd local lnDIST ""
estadd local CNTG ""
estadd local CLNY ""
estadd local LANG ""
estadd local Weights "Cohort \$ \times \$ year"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID`suffix'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID`suffix'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID`suffix'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID`suffix'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


/////////////////////////
/// Write LaTeX table ///
/////////////////////////

esttab JWDID_MAIN JWDID_BINT10 JWDID_2YRINT JWDID_5YRINT JWDID_NEVER1 JWDID_NEVER2 JWDID_NOTYET JWDID_DRPANT JWDID_COVDIST JWDID_COVGRAV JWDID_g JWDID_t JWDID_gt using "${path_tables}/Table_A5.tex", se label ///
			star(* 0.10 ** 0.05 *** 0.01) ///
			replace substitute(\_ _) nonotes noobs nonumbers b(%9.3f) se(%9.3f) ///
			mtitle("Baseline" "(1)" "(2)" "(3)" "(4)" "(5)" "(6)" "(7)" "(8)" "(9)" "(10)" "(11)" "(12)") ///
			scalars("Unit_heterogeneity \multicolumn{13}{l}{\emph{Heterogeneity}} \\ \hspace{1cm} Unit heterogeneity" "Time_heterogeneity \hspace{1cm} Time heterogeneity" "Binning \hspace{1cm} Binning" "Not_yet \hline \multicolumn{13}{l}{\emph{Control group}} \\ \hspace{1cm} Not-yet treated" "Never \hspace{1cm} Never treated" "Omit_anticipation \hline \emph{Omit anticipation periods}" "lnDIST \hline \multicolumn{13}{l}{\emph{Covariate interactions}} \\ \hspace{1cm} ln Distance" "CNTG \hspace{1cm} Contiguity" "CLNY \hspace{1cm} Colony" "LANG \hspace{1cm} Language" "Weights \hline \emph{Weights}" "N_all \hline Observations" "N_E Exporters" "N_I Importers" "N_T Years" "N_coef Coefficients" ///
			 "Exporter_Importer \hline Exporter \$\times\$ importer FE" "Exporter_Year Exporter \$\times\$ year FE" "Importer_Year Importer \$\times\$ year FE" "Intra_Year Cross-border \$\times\$ year FE") ///
			sfmt(%12.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc) ///
		coef(RTA_3 "\$ RTA_{ij,t}\$")
	