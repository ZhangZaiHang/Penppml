******************************************************************************************************************************
******************************************************************************************************************************
***
*** Table A3: Robustness with regard to degree of heterogeneity of the ETWFE estimator and incidental parameter problems
*** TWFE jackknife estimation
*** 
******************************************************************************************************************************
******************************************************************************************************************************


** global settings
local N_iter = 1000
local N_p = 4
local N_jiter = `N_iter'/`N_p'

** 0) open data set
use ${usr_data}\data_sdid_small, clear

******************************************************
*  1) Create pair ID and symmetric pair ID variables *
******************************************************

* generate 1000 bootstrap samples
set seed 123456789
forval i=1(1)`N_jiter' {

	preserve
	
	keep exporter
	duplicates drop exporter, force
	gen randn = runiform()
	egen rank=rank(randn), unique
	keep if rank>=35
	keep exporter
	qui save ${usr_data}\Simulation\data_sdid_small_jackknife_exporter`i', replace
	rename exporter importer
	qui save ${usr_data}\Simulation\data_sdid_small_jackknife_importer`i', replace
	
	restore

}
	
* initialise matrices
mat B_main = J(1,1,.)
mat N_main = J(1,1,.)

mat index = J(`N_iter',1,.)
mat B_jack = J(`N_iter',1,.)
mat N_jack = J(`N_iter',1,.)
mat B = J(1,1,.)
mat SE = J(1,1,.)
mat loCI = J(1,1,.)
mat hiCI = J(1,1,.)

* open data set
use ${usr_data}\data_sdid_small, clear

* main estimation
qui ppmlhdfe trade RTA_3, absorb(idt_ci idt_cj id_ci_cj brdr_time) cluster(id_ci_cj)

mat B_temp = e(b)
local B_main = B_temp[1,1]	
local N_main = e(N)

* run 1000 jackknife iterations
forval jiter=1(1)`N_jiter' {

	di "`jiter'"
		
	* open data set
	use ${usr_data}\data_sdid_small, clear	

	forval p=1(1)4 {

		preserve
		
		capture drop _merge_id_ci
		qui merge m:1 exporter using "${usr_data}\Simulation\data_sdid_small_jackknife_exporter`jiter'.dta"
		rename _merge _merge_id_ci
		capture drop _merge_id_cj
		qui merge m:1 importer using "${usr_data}\Simulation\data_sdid_small_jackknife_importer`jiter'.dta"
		rename _merge _merge_id_cj
		
		if `p'==1 {
			qui keep if _merge_id_ci==3
		}
		if `p'==2 {
			qui drop if _merge_id_ci==3
		}
		if `p'==3 {
			qui keep if _merge_id_cj==3
		}
		if `p'==4 {
			qui drop if _merge_id_cj==3
		}
		
		qui ppmlhdfe trade RTA_3, absorb(idt_ci idt_cj id_ci_cj brdr_time) cluster(id_ci_cj)

		mat B_temp = e(b)
		mat B_jack[(`jiter'-1)*`N_p'+`p',1] = B_temp[1,1]	
		mat N_jack[(`jiter'-1)*`N_p'+`p',1] = e(N)
		mat index[(`jiter'-1)*`N_p'+`p',1] = (`jiter'-1)*`N_p'+`p'
		
		restore
			
	}	
	
	
	
	* 0) read matrices and macros into mata
	mata: B_jack=st_matrix("B_jack")
	mata: N_jack=st_matrix("N_jack")
	mata: NN_jack = strtoreal(st_local("N_jack"))
	mata: w_jack = N_jack/sum(N_jack)
	mata: B_main = strtoreal(st_local("B_main"))
	
	* 1) beta from Weidner & Zylkin (2021); SE from distribution of beta; CI from beta_debiased +- 1.96 SE
	mata: B = 2*B_main - mean(B_jack)
	mata: SE = sqrt(quadvariance(B_jack))
	mata: loCI = B - SE*1.96
	mata: hiCI = B + SE*1.96

	* 2) pass matrices and macros back to stata

	* @ 1)
	mata: st_local("B", strofreal(B))
	mata: st_local("SE", strofreal(SE))
	mata: st_local("loCI", strofreal(loCI))
	mata: st_local("hiCI", strofreal(hiCI))
	mat B[1,1] = `B'
	mat SE[1,1] = `SE'
	mat loCI[1,1] = `loCI'
	mat hiCI[1,1] = `hiCI'
	
	qui drop _all
	qui svmat B
	qui svmat SE
	qui svmat loCI
	qui svmat hiCI
	qui svmat B_jack
	qui svmat N_jack
	qui svmat index
	
	qui rename B1 B_TWFE
	qui rename SE1 SE_TWFE
	qui rename loCI1 loCI_TWFE
	qui rename hiCI1 hiCI_TWFE
	qui rename B_jack1 B_jack_TWFE
	qui rename N_jack1 N_jack_TWFE
	qui rename index1 index
	
	* save results file
	qui save ${usr_data}\Jackknife_SEs_TWFE_random, replace

}
