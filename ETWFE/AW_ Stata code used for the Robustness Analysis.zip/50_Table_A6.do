******************************************************************************************************************************
******************************************************************************************************************************
***
*** Table A6: Robustness with regard to different gravity specifications
*** 
******************************************************************************************************************************
******************************************************************************************************************************

** 0) open data set
use ${usr_data}\data_sdid_small, clear


** 2) OLS: ETWFE
local spec "OLS"
jwdid lntrade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) fe(idt_ci idt_cj brdr_time)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
estat simple
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator_name "OLS"
estadd local Interval5_name ""
estadd local Dom_trade "Yes"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 1) OLS: TWFE
eststo TWFE_OLS: reghdfe lntrade RTA_3 if sample_JWDID_`spec'==1, absorb(idt_ci idt_cj id_ci_cj brdr_time) cluster(id_ci_cj)
local col_B = colsof(e(b))-1
* store remaining results
estadd local Estimator_name "OLS"
estadd local Interval5_name ""
estadd local Dom_trade "Yes"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'



** 4) 5-Year interval data: ETWFE
local spec "D5YRINT"
jwdid trade if int_5yr==1, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator_name "PPML"
estadd local Interval5_name "Yes"
estadd local Dom_trade "Yes"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 3) 5-Year interval data: TWFE
eststo TWFE_D5YRINT: ppmlhdfe trade RTA_3 if sample_JWDID_`spec'==1, absorb(idt_ci idt_cj id_ci_cj brdr_time) cluster(id_ci_cj)
local col_B = colsof(e(b))-1
* store remaining results
estadd local Estimator_name "PPML"
estadd local Interval5_name "Yes"
estadd local Dom_trade "Yes"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 6) No domestic trade flows: ETWFE
local spec "NOINTRA"
jwdid trade if brdr==1, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator_name "PPML"
estadd local Interval5_name ""
estadd local Dom_trade ""
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year ""
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 5) No domestic trade flows: TWFE
eststo TWFE_`spec': ppmlhdfe trade RTA_3 if sample_JWDID_`spec'==1, absorb(idt_ci idt_cj id_ci_cj) cluster(id_ci_cj)
local r2_temp = e(r2_p)
local col_B = colsof(e(b))-1
* store remaining results
estadd local Estimator_name "PPML"
estadd local Interval5_name ""
estadd local Dom_trade ""
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year ""
estadd local Exporter_Importer "Yes"
estadd scalar R2 = round(`r2_temp'*1000)/1000
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'



** 8) Add WTO as control: ETWFE
local spec "WTO"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj id_ci_cj brdr_time) exovar(WTO_3)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator_name "PPML"
estadd local Interval5_name ""
estadd local Dom_trade "Yes"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 7) Add WTO as control: TWFE
eststo TWFE_WTO: ppmlhdfe trade RTA_3 WTO_3 if sample_JWDID_`spec'==1, absorb(idt_ci idt_cj id_ci_cj brdr_time) cluster(id_ci_cj)
local col_B = colsof(e(b))-1
* store remaining results
estadd local Estimator_name "PPML"
estadd local Interval5_name ""
estadd local Dom_trade "Yes"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 10) No pair FE, but gravity controls: ETWFE
local spec "NOPAIRFE"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time) exovar(DIST CNTG LANG CLNY) group
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator_name "PPML"
estadd local Interval5_name ""
estadd local Dom_trade "Yes"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer ""
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 9) No pair FE, but gravity controls: TWFE
eststo TWFE_NOPAIRFE: ppmlhdfe trade RTA_3 DIST CNTG LANG CLNY if sample_JWDID_`spec'==1, absorb(idt_ci idt_cj brdr_time) cluster(id_ci_cj)
local col_B = colsof(e(b))-1
* store remaining results
estadd local Estimator_name "PPML"
estadd local Interval5_name ""
estadd local Dom_trade "Yes"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer ""
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 12) No exporter-year and importer-year FE: ETWFE
gen LN_GDP_EXP=ln(gdp_pwt_cur_o)
gen LN_GDP_IMP=ln(gdp_pwt_cur_d)
gen expDIST = exp(DIST)
egen gdp_pwt_cur_o_sum = sum(gdp_pwt_cur_o), by(id_cj year)
gen gdp_pwt_cur_o_w = gdp_pwt_cur_o/gdp_pwt_cur_o_sum
gen expDIST_o_temp = expDIST*gdp_pwt_cur_o_w
egen expDIST_o = sum(expDIST_o_temp), by(id_cj year)
gen DIST_o = ln(expDIST_o)
egen gdp_pwt_cur_d_sum = sum(gdp_pwt_cur_d), by(id_ci year)
gen gdp_pwt_cur_d_w = gdp_pwt_cur_d/gdp_pwt_cur_d_sum
gen expDIST_d_temp = expDIST*gdp_pwt_cur_d_w
egen expDIST_d = sum(expDIST_d_temp), by(id_ci year) 
gen DIST_d = ln(expDIST_d)
drop gdp_pwt_cur_o_sum gdp_pwt_cur_d_sum gdp_pwt_cur_o_w gdp_pwt_cur_d_w expDIST_o_temp expDIST_o expDIST_d_temp expDIST_d
local spec "NOMLR"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(brdr_time) exovar(LN_GDP_EXP LN_GDP_IMP DIST_o DIST_d)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator_name "PPML"
estadd local Interval5_name ""
estadd local Dom_trade "Yes"
estadd local Exporter_Year ""
estadd local Importer_Year ""
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'

** 11) No exporter-year and importer-year FE: TWFE
eststo TWFE_NOMLR: ppmlhdfe trade RTA_3 LN_GDP_EXP LN_GDP_IMP DIST_o DIST_d if sample_JWDID_`spec'==1, absorb(brdr_time id_ci_cj) cluster(id_ci_cj)
local col_B = colsof(e(b))-1
* store remaining results
estadd local Estimator_name "PPML"
estadd local Interval5_name ""
estadd local Dom_trade "Yes"
estadd local Exporter_Year ""
estadd local Importer_Year ""
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


/////////////////////////
/// Write LaTeX table ///
/////////////////////////

esttab TWFE_OLS JWDID_OLS TWFE_D5YRINT JWDID_D5YRINT TWFE_NOINTRA JWDID_NOINTRA TWFE_WTO JWDID_WTO TWFE_NOPAIRFE JWDID_NOPAIRFE TWFE_NOMLR JWDID_NOMLR using "${path_tables}/Table_A6.tex", se label ///
			star(* 0.10 ** 0.05 *** 0.01) ///
			replace substitute(\_ _) nonotes noobs b(%9.3f) se(%9.3f) drop(_cons) ///
			mtitle("TWFE" "ETWFE" "TWFE" "ETWFE" "TWFE" "ETWFE" "TWFE" "ETWFE" "TWFE" "ETWFE" "TWFE" "ETWFE") ///
			scalars("Estimator_name Estimator" "Dom_trade Domestic trade" "Interval5_name 5-yr interval" "N_all \hline  Observations" "N_E Exporters" "N_I Importers" "N_T Years" "N_coef Coefficients" ///
			 "Exporter_Importer \hline Exporter \$\times\$ importer FE" "Exporter_Year Exporter \$\times\$ year FE" "Importer_Year Importer \$\times\$ year FE" "Intra_Year Cross-border \$\times\$ year FE") ///
			sfmt(%12.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc) ///
		coef(RTA_3 "\$ RTA_{ij,t}\$" ///
			 WTO_3 "\$ WTO_{ij,t}\$" ///
			 DIST "\$ DIST_{ij}\$" ///
			 CNTG "\$ CNTG_{ij}\$" ///
			 LANG "\$ LANG_{ij}\$" ///
			 CLNY "\$ CLNY_{ij}\$" ///
			 LN_GDP_EXP "\$ GDP_{i,t}\$" ///
			 LN_GDP_IMP "\$ GDP_{j,t}\$" ///
			 DIST_d "\$ REM_{i,t}\$" ///
			 DIST_o "\$ REM_{j,t}\$")

