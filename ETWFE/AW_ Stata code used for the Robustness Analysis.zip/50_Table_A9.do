******************************************************************************************************************************
******************************************************************************************************************************
***
*** Table A9: Robustness with regard to clustering of standard errors and additional results on depth of agreements
*** 
******************************************************************************************************************************
******************************************************************************************************************************

** open data set
use ${usr_data}\data_sdid_small, clear


** 0) Baseline
local spec "MAIN"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator "ETWFE"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
estadd local SE_clustering "Exp\$\times\$ Imp"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 1) Two-way clustering (on exporter and importer dimension)
local spec "TWOWAY1"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time) cvar(id_ci id_cj)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator "ETWFE"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
estadd local SE_clustering "Exp, Imp"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 2) Two-way clustering (on exporter-time and importer-time dimension)
local spec "TWOWAY2"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time) cvar(idt_ci idt_cj)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator "ETWFE"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
estadd local SE_clustering "Exp\$\times\$ year, Imp\$\times\$ year"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'


** 3) Three-way clustering (on exporter, importer, and year dimension)
local spec "THREEWAY"
jwdid trade, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time) cvar(id_ci id_cj year)
estimates save "${usr_data}\base_`spec'.ster", replace
local col_B = colsof(e(b))-1
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estat simple, predict(xb)
mat B = [r(b)]
mat V = (r(V))
matrix colnames B = RTA_3
matrix colnames V = RTA_3
matrix rownames V = RTA_3
ereturn post B V
eststo JWDID_`spec'
* store remaining results
estadd local Estimator "ETWFE"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
estadd local SE_clustering "Exp, Imp, year"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'

// save post estimation data set
save ${usr_data}\data_sdid_se_post, replace

* compute maximum number of provisions by pair over time
egen max_DEPTH = max(DEPTH), by(id_ci_cj)
replace DEPTH=max_DEPTH

* define median split
sum DEPTH if DEPTH>0 & DEPTH!=., d
gen DEPTH_P50 = DEPTH>r(p50) & DEPTH!=.

** 5) DEPTH median split
local spec "P50"
jwdid trade if first_treat_LARCH_3==first_treat_3, ivar(id_ci_cj) tvar(year) gvar(first_treat_3) method(ppmlhdfe) fe(idt_ci idt_cj brdr_time) addint(DEPTH_P50)
gen sample_JWDID_`spec' = e(sample)
gen __tr__JWDID_`spec' = __tr__
gen __etr__JWDID_`spec' = __etr__
gen _ppmlhdfe_d_JWDID_`spec' = _ppmlhdfe_d
estimates save "${usr_data}\base_`spec'.ster", replace

local suffix = "_P50"
local spec = "P50"
local event_gvar = "first_treat_3"

estimates use "${usr_data}\base`suffix'.ster"
estimates esample: if sample_JWDID`suffix'
capture drop __tr__ __etr__ _ppmlhdfe_d
gen __tr__ = __tr__JWDID`suffix'
gen __etr__ = __etr__JWDID`suffix'
gen double _ppmlhdfe_d = _ppmlhdfe_d_JWDID`suffix'
local col_B = colsof(e(b))-1

gen DEPTH_bin2 = 0
replace DEPTH_bin2 = 1 if sample_JWDID_`spec' & __etr__JWDID_`spec' & DEPTH_P50==1

margins , subpop(if __etr__==1) at(__tr__=(0 1)) ///
				over(DEPTH_bin2) noestimcheck contrast(atcontrast(r)) predict(xb)

mat table = r(table)
mat B = table["b",1...]'
mat V = J(2,2,0)
mat V[1,1]=table[2,1]^2
mat V[2,2]=table[2,2]^2
matrix colnames B = B
matrix rownames B = DEPTH0 DEPTH1
matrix colnames V = DEPTH0 DEPTH1
matrix rownames V = DEPTH0 DEPTH1
mat B = B'
ereturn post B V
eststo JWDID_`spec'
estadd local Estimator "ETWFE"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
estadd local SE_clustering "Exp\$\times\$ Imp"
count if sample_JWDID`suffix'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID`suffix'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID`suffix'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID`suffix'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'		

** 4) TWFE with EXP-IMP, EXP-Year, and IMP-Year FE
gen DEPTH0 = RTA_3*(DEPTH_P50==0)
gen DEPTH1 = RTA_3*(DEPTH_P50==1)
local spec = "P50"
eststo TWFE_`spec': ppmlhdfe trade DEPTH0 DEPTH1 if sample_JWDID_`spec'==1, absorb(idt_ci idt_cj id_ci_cj brdr_time) cluster(id_ci_cj)
local col_B = colsof(e(b))-1
* store remaining results
estadd local Estimator "TWFE"
estadd local Exporter_Year "Yes"
estadd local Importer_Year "Yes"
estadd local Intra_Year "Yes"
estadd local Exporter_Importer "Yes"
estadd local SE_clustering "Exp\$\times\$ Imp"
count if sample_JWDID_`spec'==1
estadd scalar N_all = `r(N)'
unique exporter if sample_JWDID_`spec'==1
estadd scalar N_E = `r(unique)'
unique importer if sample_JWDID_`spec'==1
estadd scalar N_I = `r(unique)'
unique year if sample_JWDID_`spec'==1
estadd scalar N_T = `r(unique)'
estadd scalar N_coef = `col_B'

/////////////////////////
/// Write LaTeX table ///
/////////////////////////

esttab JWDID_MAIN JWDID_TWOWAY1 JWDID_TWOWAY2 JWDID_THREEWAY TWFE_P50 JWDID_P50 using "${path_tables}/Table_A9.tex", se label ///
			star(* 0.10 ** 0.05 *** 0.01) ///
			replace substitute(\_ _) nonotes nonumber noobs b(%9.3f) se(%9.3f) drop(*cons*) ///
			mtitle("Baseline" "(1)" "(2)" "(3)" "(4)" "(5)") ///
			scalars("Estimator Estimator" "N_all \hline Observations" "N_E Exporters" "N_I Importers" "N_T Years" "N_coef Coefficients" ///
			 "Exporter_Importer \hline Exporter \$\times\$ importer FE" "Exporter_Year Exporter \$\times\$ year FE" "Importer_Year Importer \$\times\$ year FE" "Intra_Year Cross-border \$\times\$ year FE" "SE_clustering Standard error clustering") ///
			sfmt(%12.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc %9.0gc) ///
		coef(RTA_3 "\$ RTA_{ij,t}\$" ///
			 DEPTH0 "\$ DEPTH_{ij,t}<P50\$" ///
			 DEPTH1 "\$ DEPTH_{ij,t}>=P50\$")
		
